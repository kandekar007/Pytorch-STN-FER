# Pytorch-STN-FER

### Just run that .ipynb file

Credits for base FER Pipeline: "https://www.kaggle.com/balmukund/fer-2013-pytorch-implementation"
<br />
Added STN module over the base pipeline to improve efficiency.
